package com.example.currencyconverterapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    String[] country = { "USD", "AUD", "CAD", "INR", "EUR"};
    Spinner spinnerBase,spinnerTarget;
    ArrayAdapter baseAdapter,targetAdapter;
    String baseCurrency,targetCurrency;

    Button convert,logout;
    EditText editTextBase,editTextTarget;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextBase = (EditText) findViewById(R.id.editTextBase);
        editTextTarget = (EditText) findViewById(R.id.editTextTarget);
        convert = (Button) findViewById(R.id.convert);
        logout = (Button) findViewById(R.id.logout);

        spinnerBase = (Spinner) findViewById(R.id.spinner);
        spinnerTarget = (Spinner) findViewById(R.id.spinner2);

        baseAdapter = new ArrayAdapter(this,android.R.layout.simple_spinner_item,country);
        baseAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerBase.setAdapter(baseAdapter);

        spinnerBase.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                baseCurrency=country[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        targetAdapter = new ArrayAdapter(this,android.R.layout.simple_spinner_item,country);
        targetAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerTarget.setAdapter(targetAdapter);
        spinnerTarget.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                targetCurrency=country[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        convert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String number= editTextBase.getText().toString().trim();
                if(number.equals("")){
                    editTextBase.setError("Enter number");
                }else {
                    callRatesAPI(baseCurrency, targetCurrency);
                }
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,LoginActivity.class));
                finish();
            }
        });


    }
    private void callRatesAPI(String base,String target) {


        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, "https://free.currconv.com/api/v7/convert?q="+base+"_"+target+"&compact=ultra&apiKey=b0e9b60e3efe00f881c0", null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {


                                String data = response.getString(base+"_"+target);
                            String number = editTextBase.getText().toString().trim();
                            double conversion=Double.parseDouble(number)*Double.parseDouble(data);
                            editTextTarget.setText(String.valueOf(conversion));

                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();

                    }
                }) {

        };
        RequestQueue requestQueue1 = Volley.newRequestQueue(MainActivity.this);
        requestQueue1.add(request);
    }

}