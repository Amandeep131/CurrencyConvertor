package com.example.currencyconverterapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class RegisterActivity extends AppCompatActivity {

    Button register;
    TextView textView;
    SQLiteDatabase offlineDb;
    EditText username,editTextTextEmailAddress,editTextTextPassword,confirmPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        register= findViewById(R.id.register);

        username=findViewById(R.id.username);
        editTextTextEmailAddress=findViewById(R.id.editTextTextEmailAddress);
        editTextTextPassword=findViewById(R.id.editTextTextPassword);
        confirmPassword=findViewById(R.id.confirmPassword);



        offlineDb = this.openOrCreateDatabase("OfflineUserDatabase", MODE_PRIVATE, null);
        offlineDb.execSQL("CREATE TABLE IF NOT EXISTS Users (id INTEGER PRIMARY KEY, username VARCHAR, email VARCHAR, password VARCHAR)");

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(username.getText().toString().equals("")){
                    username.setError("Please Enter User Name");
                }else if (!isValidEmail(editTextTextEmailAddress.getText().toString())) {
                    editTextTextEmailAddress.setError("Please enter valid Email Id");
                    editTextTextEmailAddress.requestFocus();
                }else if(editTextTextEmailAddress.getText().toString().equals("")){
                    editTextTextEmailAddress.setError("Please Enter Email");
                }else if(editTextTextPassword.getText().toString().equals("")){
                    editTextTextPassword.setError("Please Enter Password");
                }
                else if(!confirmPassword.getText().toString().equals(editTextTextPassword.getText().toString())){
                    confirmPassword.setError("Please Enter same password again Password");
                }
                else {
                    String sql = "INSERT INTO Users (username, email, password) VALUES (?, ?, ?)";
                    SQLiteStatement statement = offlineDb.compileStatement(sql);
                    statement.bindString(1, username.getText().toString());
                    statement.bindString(2, editTextTextEmailAddress.getText().toString());
                    statement.bindString(3, confirmPassword.getText().toString());
                    statement.execute();
                    startActivity(new Intent(RegisterActivity.this, MainActivity.class));
                }
            }
        });
        textView= findViewById(R.id.textView);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegisterActivity.this,LoginActivity.class));
            }
        });
    }
    public boolean isValidEmail(String email) {
        return !TextUtils.isEmpty(email) && android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();

    }
}