package com.example.currencyconverterapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    Button login;
    TextView textView;
    EditText editTextTextEmailAddress,editTextTextPassword;
    SQLiteDatabase offlineDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        login= findViewById(R.id.login);
        editTextTextEmailAddress=findViewById(R.id.editTextTextEmailAddress);
        editTextTextPassword=findViewById(R.id.editTextTextPassword);
        offlineDb = this.openOrCreateDatabase("OfflineUserDatabase", MODE_PRIVATE, null);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email=editTextTextEmailAddress.getText().toString();
                String password=editTextTextPassword.getText().toString();
                if(email.equals("")){
                    editTextTextEmailAddress.setError("Please Enter Email");
                }else if (!isValidEmail(editTextTextEmailAddress.getText().toString())) {
                    editTextTextEmailAddress.setError("Please enter valid Email Id");
                    editTextTextEmailAddress.requestFocus();
                }else if(password.equals("")){
                    editTextTextPassword.setError("Please Enter Password");
                }else {

                    //create a database if one does not exists

                    //load the record where the parameter url is a matching attribute
                    String databaseemail = "";
                    Cursor c = offlineDb.rawQuery("SELECT * FROM Users where email==\"" + email + "\" AND password==\"" + password + "\"", null);
                    int contentIndex = c.getColumnIndex("email");
                    if (c.moveToFirst()) {
                        do {
                            //get the detailed body of the content, at this moment the content is an empty string...
                            databaseemail = c.getString(contentIndex);
                        } while (c.moveToNext());

                    }
                    if(!databaseemail.equals("")) {
                        startActivity(new Intent(LoginActivity.this, MainActivity.class));
                    }else{
                        Toast.makeText(LoginActivity.this,"Wrong Email/Password",Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
        textView= findViewById(R.id.textView);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this,RegisterActivity.class));
            }
        });
    }
    public boolean isValidEmail(String email) {
        return !TextUtils.isEmpty(email) && android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();

    }
}